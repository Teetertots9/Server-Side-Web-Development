To run

npm install

npm run dev